﻿using UnityEngine;
using System.Collections;

public class IRobotController {
	//this class will be used to hook with robot hardware --> load C++ plugins
}
