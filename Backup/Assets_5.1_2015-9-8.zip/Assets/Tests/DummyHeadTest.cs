﻿using UnityEngine;
using System.Collections;
using UnityEngine.VR;

public class DummyHeadTest : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 e=InputTracking.GetLocalRotation(VRNode.Head).eulerAngles;
		transform.localRotation = Quaternion.Euler(e);
	}
}
