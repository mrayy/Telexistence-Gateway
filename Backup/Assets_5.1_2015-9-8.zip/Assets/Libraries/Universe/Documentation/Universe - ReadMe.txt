=== Universe ===
by LightStriker Software

This is a very simple package that will change how you see your scene flow and how you work in the editor.

It adds a virtual layer above scenes, allow you to create game-wide managers without any kind of maintenance required.


== Bugs, Issues, Support ==

You can contact us directly and we will answer as quickly as possible.

Email : admin@lightstrikersoftware.com
Website : www.lightstrikersoftware.com

You can also contact us on Unity's forum, user "LightStriker".


== FAQ ==

- Mac? Linux?

We didn't test this on Linux, but we did on Mac. 

- iOS? Android?

It was tested in project for both platform and works fine.

- I found a bug!

Contact us right away! We will fix it ASAP.

- I got idea for other features...

Again, contact us! We will look into adding that feature - if humanly possible - as quickly as we can.

- I don't understand how it works, how to use it or how to implement it!

Contact us, we will gladly help you.


== Version ==

1.0:
- Release