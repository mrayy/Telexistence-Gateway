﻿using UnityEngine;
using System.Collections;
//using UnityEditor;

public class Startup {

	static Startup()
	{
	}
}
