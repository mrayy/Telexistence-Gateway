﻿using UnityEngine;
using System.Collections;

public class DisplayConfigurations : MonoBehaviour {

	public float FOV;
	public Vector2 Size;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
