﻿using UnityEngine;
using System.Collections;
using UnityEngine.VR;

public class OculusHeadController : IRobotHeadControl {

	Quaternion _initial;

	public bool GetHeadOrientation(out Quaternion q, bool abs)
	{
		if (!VRDevice.isPresent) {
			q=Quaternion.identity;
			return false;
		}

		q = InputTracking.GetLocalRotation(VRNode.Head);
		if (!abs) {
		//	q=q*_initial;
		}
		q.x = -q.x;
		q.y = -q.y;
		return true;
	}
	public bool GetHeadPosition(out Vector3 v,bool abs)
	{
		
		if (!VRDevice.isPresent) {
			v=Vector3.zero;
			return false;
		}
		v = InputTracking.GetLocalPosition (VRNode.Head);
		return true;
	}
	
	public void Recalibrate()
	{
		
		if (VRDevice.isPresent) {
			InputTracking.Recenter();
		}
	}
}
