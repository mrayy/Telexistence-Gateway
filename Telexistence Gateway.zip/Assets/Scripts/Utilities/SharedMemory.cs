﻿using UnityEngine;
using System.Collections;

public class SharedMemory  {

	string _name;
	public string Name
	{
		get{
			return _name;
		}
	}
	public SharedMemory()
	{
	}

}
